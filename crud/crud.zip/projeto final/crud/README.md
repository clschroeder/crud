# crud
app de um crud simples em Java8, Spring Boot, Spring MVC, Spring JPA, PostgreSQL, Docker, Swagger, Maven

# Rodar o app
1. mvn clean install
2. docker-compose up --build
3. Abra no navegador http://localhost:8080/swagger-ui.html to check api
